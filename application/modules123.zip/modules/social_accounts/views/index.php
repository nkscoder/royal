<?php
/**
 * Created by PhpStorm.
 * User: tushar
 * Date: 21/9/15
 * Time: 4:15 PM
 */
getInformUser();
?>
<!--<a href="social_accounts/doFacebookLogin">Add facebook Account</a>-->
    <a href="<?php echo htmlspecialchars($facebook_login_url);?>">Post on your facebook Wall</a>
<a href="#">Add google Account</a>
<?php ?>